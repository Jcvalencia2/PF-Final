<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Handle form submission and database insertion
    $studentID = $_POST['studentID'];
    $studentName = $_POST['studentName'];
    $course = $_POST['course'];
    $vehicleModel = $_POST['vehicleModel'];

    // Validate and sanitize input here if needed

    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'psauqr_db');
    
    if ($conn->connect_error) {
        die("Connection Failed : " . $conn->connect_error);
    } else {
        $stmt = $conn->prepare("INSERT INTO form (studentID, studentName, course, vehicleModel) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $studentID, $studentName, $course, $vehicleModel);
        
        if ($stmt->execute()) {
            // Data inserted successfully
            echo "Data successfully imported!";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
        $conn->close();
    }
}
?>
