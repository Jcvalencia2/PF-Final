<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">  
    <title>PSAU QR Code Generator</title>
    <link rel="stylesheet" href="style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  </head>
  <body>
    <div class="wrapper">
      <div class="logo-container">
        <img src="2-removebg-preview.png" alt="Logo">
      </div>
      <header>
        <h1>PSAU QR Code Generator</h1>
        <p>Please complete the form.</p>
      </header>
    
      <form action="connect.php" method="post">
        <div class="form">
          <label for="schoolId">School ID:</label>
          <input type="text" id="schoolId" name="studentID" spellcheck="false" placeholder="Enter School ID">

          <label for="studentName">Student Name:</label>
          <input type="text" id="studentName" name="studentName" spellcheck="false" placeholder="Enter Student Name">
        
          <label for="course">Course:</label>
          <input type="text" id="course" name="course" spellcheck="false" placeholder="Enter Course">

          <label for="vehicleModel">Vehicle Model:</label>
          <input type="text" id="vehicleModel" name="vehicleModel" spellcheck="false" placeholder="Enter Vehicle Model">

          <button type="submit">Generate QR Code</button>
        </div>
      </form>
      
      <div class="qr-code">
        <img src="" alt="qr-code">
      </div>
    </div>

    <script src="script.js"></script>
  </body>
</html>