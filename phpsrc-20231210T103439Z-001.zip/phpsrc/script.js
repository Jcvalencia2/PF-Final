const wrapper = document.querySelector(".wrapper"),
  qrInputs = wrapper.querySelectorAll(".form input"),
  generateBtn = wrapper.querySelector(".form button"),
  qrImg = wrapper.querySelector(".qr-code img");
let preValues = [];

function generateQRCode() {
  let qrValue = "";
  qrInputs.forEach((input) => {
    qrValue += input.value.trim() + " ";
  });

  if (!qrValue.trim() || preValues.includes(qrValue)) return;
  preValues.push(qrValue);

  generateBtn.innerText = "Generating QR Code...";
  qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(qrValue)}`;
  
  qrImg.onload = () => {
    wrapper.classList.add("active");
    generateBtn.innerText = "Generate QR Code";
  };
}

qrInputs.forEach((input) => {
  input.addEventListener("keyup", () => {
    if (!qrInputs[0].value.trim()) {
      wrapper.classList.remove("active");
      preValues = [];
    }
  });
});
